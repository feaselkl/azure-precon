def add_numbers(a, b):
    print("We are adding two numbers together.")
    return a + b